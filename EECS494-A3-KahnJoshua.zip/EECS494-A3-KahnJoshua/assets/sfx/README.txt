File 104469__dkmedic__world.wav ("booming male voice 
  announcing hello world, this is the event mankind has 
  been waiting for.") is
copyright 2010 by dkmedic and is licensed under a
Creative Commons Sampling+ License:
  http://creativecommons.org/licenses/sampling+/1.0/
According to:
  http://www.freesound.org/people/dkmedic/sounds/104469/
